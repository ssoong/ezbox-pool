git config push.default tracking
git config branch.autosetuprebase always

