sender_id = '38f857b8-cbaa-4b58-9271-0d36c27813c4'
io_threads = 1
views = "views/"
config_db = 'conf/config.sqlite'
host='(.+)'
