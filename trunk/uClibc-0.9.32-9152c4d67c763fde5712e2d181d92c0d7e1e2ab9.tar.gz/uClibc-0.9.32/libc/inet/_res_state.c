/*
 * Copyright (C) 2006 Steven J. Hill <sjhill@realitydiluted.com>
 *
 * Licensed under the LGPL v2.1, see the file COPYING.LIB in this tarball.
 */

#define L_res_state
#include RESOLVER
