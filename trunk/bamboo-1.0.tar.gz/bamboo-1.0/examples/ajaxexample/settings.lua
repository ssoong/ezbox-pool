project_name = "ajaxexample"
host = 'ajaxexample'

sender_id = '99edc750-f2bc-1f04-ffc7-cb0301efa240'
io_threads = 1
views = "views/"
config_file = 'config.lua'
WHICH_DB = 15

debug_level = 1
