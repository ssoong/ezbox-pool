project_name = "cache_test"
host = "cache_test"
sender_id = 'c62c1bda-0816-2205-eef9-811c8e055fd1'
io_threads = 1
views = "views/"
config_file = 'config.lua'
WHICH_DB = 15

debug_level = 1