const char *cpu_to_uname_machine(void *cpu_env);
